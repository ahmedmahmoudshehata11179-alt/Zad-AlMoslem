package com.zadalmuslim.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final String[] tasks = {
        "صلاة الفجر", "أذكار الصباح", "ورد القراءة", "صلاة الضحى",
        "صلاة الظهر", "صلاة العصر", "أذكار المساء", "صلاة المغرب",
        "صلاة العشاء", "ورد الحفظ", "أذكار قبل النوم"
    };
    private SharedPreferences prefs;
    private int tasbeeh = 0;
    private TextView countView;
    private LinearLayout root;
    private final int green = Color.rgb(20, 75, 56);
    private final int gold = Color.rgb(190, 150, 65);
    private final int cream = Color.rgb(250, 247, 238);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("zad", MODE_PRIVATE);
        tasbeeh = prefs.getInt("tasbeeh", 0);
        buildUi(false);
    }

    private GradientDrawable rounded(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(28);
        if (stroke > 0) d.setStroke(2, stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(12, 12, 12, 12);
        return t;
    }

    private void buildUi(boolean dark) {
        int bg = dark ? Color.rgb(18, 28, 24) : cream;
        int card = dark ? Color.rgb(35, 48, 42) : Color.WHITE;
        int fg = dark ? Color.WHITE : green;

        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 22, 18, 28);
        root.setBackgroundColor(bg);
        scroll.addView(root);

        TextView title = text("☪ زاد المسلم", 29, dark ? Color.rgb(225,194,117) : green, true);
        root.addView(title);
        root.addView(text("يومي مع الله • خطوتك الصغيرة تصنع فرقًا", 15, fg, false));
        root.addView(text("التاريخ: " + java.text.DateFormat.getDateInstance().format(new java.util.Date()), 14, fg, false));

        LinearLayout cardTasks = new LinearLayout(this);
        cardTasks.setOrientation(LinearLayout.VERTICAL);
        cardTasks.setPadding(12, 10, 12, 10);
        cardTasks.setBackground(rounded(card, gold));
        root.addView(cardTasks, matchWrap());
        cardTasks.addView(text("🌿 مهامي اليومية", 21, fg, true));
        for (int i = 0; i < tasks.length; i++) {
            final int idx = i;
            CheckBox cb = new CheckBox(this);
            cb.setText(tasks[i]);
            cb.setTextSize(17);
            cb.setTextColor(fg);
            cb.setButtonTintList(android.content.res.ColorStateList.valueOf(gold));
            cb.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            cb.setChecked(prefs.getBoolean("task_" + i, false));
            cb.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("task_" + idx, checked).apply());
            cardTasks.addView(cb);
        }

        addSection("📿 السبحة الإلكترونية", "اضغط للتسبيح، واضغط تصفير لبدء عدّ جديد", card, fg);
        LinearLayout tasRow = new LinearLayout(this);
        tasRow.setGravity(Gravity.CENTER);
        countView = text(String.valueOf(tasbeeh), 28, gold, true);
        Button plus = new Button(this); plus.setText("سبّح +");
        plus.setOnClickListener(v -> { tasbeeh++; prefs.edit().putInt("tasbeeh", tasbeeh).apply(); countView.setText(String.valueOf(tasbeeh)); });
        Button reset = new Button(this); reset.setText("تصفير");
        reset.setOnClickListener(v -> { tasbeeh = 0; prefs.edit().putInt("tasbeeh", 0).apply(); countView.setText("0"); });
        tasRow.addView(plus); tasRow.addView(countView); tasRow.addView(reset);
        root.addView(tasRow);

        addSection("📖 القرآن الكريم", "سجّل إنجاز ورد القراءة والحفظ من قائمة المهام أعلاه. المصحف الكامل وتحديد آخر موضع قراءة يحتاجان إضافة لاحقة.", card, fg);
        addSection("🕌 مواقيت الصلاة", "يمكنك متابعة مواقيت الصلاة من تطبيق موثوق في جهازك حاليًا؛ المواقيت التلقائية غير مفعّلة في هذه النسخة.", card, fg);
        addSection("🔔 التذكيرات", "هذه النسخة لا ترسل إشعارات تلقائية بعد؛ يمكن إضافتها في تحديث لاحق.", card, fg);
        addSection("📊 متابعة الإنجاز", "", card, fg);
        Button progress = new Button(this);
        progress.setText("احسب إنجاز اليوم");
        progress.setOnClickListener(v -> {
            int done = 0;
            for (int i = 0; i < tasks.length; i++) if (prefs.getBoolean("task_" + i, false)) done++;
            Toast.makeText(this, "إنجاز اليوم: " + done + " من " + tasks.length + " (" + (done * 100 / tasks.length) + "%)", Toast.LENGTH_LONG).show();
        });
        root.addView(progress);
        Button theme = new Button(this);
        theme.setText("تبديل الوضع الليلي");
        theme.setOnClickListener(v -> { boolean next = !prefs.getBoolean("dark", false); prefs.edit().putBoolean("dark", next).apply(); buildUi(next); });
        root.addView(theme);
        root.addView(text("اللهم أعنّا على ذكرك وشكرك وحسن عبادتك", 15, gold, true));
        setContentView(scroll);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void addSection(String heading, String body, int card, int fg) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(12, 8, 12, 8);
        box.setBackground(rounded(card, gold));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, 16, 0, 0);
        root.addView(box, lp);
        box.addView(text(heading, 19, fg, true));
        if (body != null && !body.isEmpty()) box.addView(text(body, 14, fg, false));
    }
}
